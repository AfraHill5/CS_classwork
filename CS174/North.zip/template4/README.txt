I believe this project implemented all of the spec. The spinning triangle was rendered vertex by vertex, while the robot was
modeled hierarchically. His suit was mapped as a texture, represented by min_suit_square.tga. The frame rate should
display in the window, and running the code faithfully creates the scene without editing.

It's up to you to determine the complexity and overall quality I guess :)

I had some issues getting the robot to walk correctly in accordance with the TIME variable -- everything else seemed to work, 
but different framerates means that occasionally he seems to walk too far / not far enough and the shots are messed up.
I believe I have resolved this issue on my computer + the SEAS machines, but I haven't tested it on Xcode or another 
platform so it may still be slightly off.

